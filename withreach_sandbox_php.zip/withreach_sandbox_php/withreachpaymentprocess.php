<?php

class WithReachGateway
{
    private $apiUsername;
    private $apiPassword;
    private $baseUrl = "https://api.sandbox.withreach.com";

    public function __construct($apiUsername, $apiPassword)
    {
        $this->apiUsername = $apiUsername;
        $this->apiPassword = $apiPassword;
    }

    private function getAuthHeader()
    {
		$credentials = base64_encode(
            $this->apiUsername . ":" . $this->apiPassword
        );

        
        
    
        return ["Content-Type: application/json','Authorization: Basic ". $credentials];
    }

    private function makeRequest($method,$endpoint,$data)
    {  
	 $url = $this->baseUrl.$endpoint;
	   $headers = $this->getAuthHeader();
		//print_r ($headers) ; exit;
	$json_data = json_encode($data);
	
	//$signature = base64_encode(hash_hmac('sha256', $json_data, $secret, TRUE));
	
        $curl = curl_init();
      
        // Set cURL options
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => 'POST',
		    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Basic YWNjb3VudDpzZWNyZXQ=' // Base64 encoded credentials
    ],
			CURLOPT_POSTFIELDS => $json_data, // if its a CHECKOUT API then pass $signature
        ]);

		
        // Execute cURL request
        $response = curl_exec($curl);
		print_r($response);
		
		
        // Close cURL session
        curl_close($curl);
		
		return json_decode($response, true);
    }

    public function Session($amount,$currency,$cardNumber,$expMonth,$expYear,$card_cvv) {
        $endpoint = "/v1/session";

        $data = [
            "MerchantReference" => "unique_reference_provided_by_merchant",
            "Currency" => "USD",
            "Items" => [
                [
                    "Name" => "Item 1",
                    "Amount" => $amount,
                    "Quantity" => 1,
                ],
                [
                    "Name" => "Item 2",
                    "Amount" => $amount,
                    "Quantity" => 2,
                ],
            ],
            "BillingProfile" => [
                "BillingProfileReference" => "MerchantSupplied-reference",
                "Name" => "First Last",
                "Email" => "email@example.org",
                "Birthdate" => "1980-01-02",
                "Company" => "Umbrella corp",
                "NationalIdentifier" => "43.236.560/0001-52",
                "Address" => [
                    "Street" => "123 Street",
                    "City" => "City",
                    "Region" => "SC",
                    "Country" => "BR",
                    "Postcode" => "12345678",
                    "Phone" => "4031234567",
                ],
            ],
            "ShippingDetails" => [
                "ShippingAmount" => 0.0,
                "DutyAmount" => 0.0,
                "Name" => "First Last",
                "Email" => "email@example.org",
                "Phone" => "4031231234",
                "Address" => [
                    "Street" => "123 Street",
                    "City" => "City",
                    "Region" => "AB",
                    "Country" => "CA",
                    "Postcode" => "X0X0X0",
                ],
            ],
            "Discounts" => [
                [
                    "Name" => "Discount 1",
                    "Amount" => 2.0,
                ],
                [
                    "Name" => "Discount 2",
                    "Amount" => 3.0,
                ],
            ],
            "TaxAmount" => 1.0,
            "AutoCapture" => true,
            "CompleteUrl" =>
                "https://www.send-user-here-after-success-redirect.com",
            "CancelUrl" =>
                "https://www.send-user-here-after-failed-redirect.com",
            "ViaAgent" => false,
            "AllowContract" => true,
            "OpenContract" => false,
        ];
        return $this->makeRequest("POST", $endpoint, $data);
    }

    public function sale($amount,$currency,$cardNumber,$expMonth,$expYear,$card_cvv) { 
	$endpoint = "/v1/orders";
        $data = [
            "MerchantReference" => "SomeReference",
            "BillingProfile" => [
                "BillingProfileReference" => "Profile reference",
                "Name" => "bill name",
                "Email" => "bill@email.com",
                "Phone" => "9876543210",
                "Birthdate" => "1980-01-02",
                "Address" => [
                    "Street" => "billstreet",
                    "City" => "billcity",
                    "Region" => "billregion",
                    "Country" => "US",
                    "Postcode" => "90210",
                ],
            ],
            "Currency" => "EUR",
            "Items" => [
                [
                    "Name" => "Item 1",
                    "Amount" => 1,
                    "Quanitity" => 1,
                ],
                [
                    "Name" => "Item 2",
                    "Amount" => 2,
                    "Quantity" => 2,
                ],
            ],
            "Discounts" => [
                [
                    "Name" => "Discount 1",
                    "Amount=>" => 3,
                ],
            ],
            "ShippingDetails" => [
                "ShippingAmount" => 4.05,
                "DutyAmount" => 5.05,
                "Name" => "Shipping Name",
                "Email" => "ship@email.com",
                "Phone" => "1234567890",
                "Address" => [
                    "Street" => "shipping street",
                    "City" => "shipping city",
                    "Region" => "shipping region",
                    "Country" => "CA",
                    "Postcode" => "H0H0H0",
                ],
            ],
            "DeviceFingerprint" => "b16f631b-931f-4bfb-adb4-402f94c3e49c",
            "TaxAmount" => 6.06,
            "ViaAgent" => false,
            "AutoCapture" => true,
            "OpenContract" => false,
            "Meta" => [
                "field" => "value",
                "AnotherField" => "Some other value",
            ],
            "Payment" => [
                "Type" => "CARD",
                "Method" => "VISA",
                "Card" => "",
            ],
        ];
		
		
		
        return $this->makeRequest("POST", $endpoint, $data);
    }

    public function authorize(
        $amount,
        $currency,
        $cardNumber,
        $expMonth,
        $expYear,
        $card_cvv
    ) {
        $endpoint = "/authorize";
        $data = [
            "amount" => $amount,
            "currency" => $currency,
            "paymentMethod" => [
                "type" => "creditCard",
                "creditCard" => [
                    "number" => $cardNumber,
                    "expirationMonth" => $expMonth,
                    "expirationYear" => $expYear,
                    "cvv" => $card_cvv,
                ],
            ],
        ];
        return $this->makeRequest("POST", $endpoint, $data);
    }

		
    public function capture($transactionId, $amount = null)
    {
        $endpoint = "/v1/orders/{$transactionId}/capture";
        $data = $amount !== null ? ["amount" => $amount] : null;
		
        return $this->makeRequest("POST", $endpoint, $data);
    }

    public function voidtxt($transactionId,$amount)
    {
        $endpoint = "/v1/orders/{$transactionId}/void";
		$data = [
            "Amount" => $amount,
            "RefundReference" => "b16f631b-931f-4bfb-adb4-402f94c3e49c",
            
        ];
       
		return $this->makeRequest("POST", $endpoint, $data);
    }
	
	

    public function refund($transactionId, $amount)
    {
        $endpoint = "/v1/orders/{$transactionId}/refund";
        $data = ["amount" => $amount];
        return $this->makeRequest("POST", $endpoint, $data);
    }
}

// Example usage
$gateway = new WithReachGateway("account", "secret");

// Sale process

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $auth = "";
    $sale = "";
    $capture = "";
    $void = "";
    $refund = "";
	$session  = "";

    if (isset($_POST["auth_txt"])) {
        // auth_txt is set, do something with it
        $auth = $_POST["auth_txt"];
    }
    if (isset($_POST["sale_txt"])) {
        // auth_txt is set, do something with it
        $sale = $_POST["sale_txt"];
    }

    if (isset($_POST["capture_txt"])) {
        // auth_txt is set, do something with it
        $capture = $_POST["capture_txt"];
    }

    if (isset($_POST["void_txt"])) {
        // auth_txt is set, do something with it
        $void = $_POST["void_txt"];
    }

    if (isset($_POST["refund_txt"])) {
        // auth_txt is set, do something with it
        $refund = $_POST["refund_txt"];
    }

    if ($auth == "auth") {
        $amount = $_POST["amount"];
        $currency = $_POST["currency"];
        $cardNumber = $_POST["cardNumber"];
        $expMonth = $_POST["expMonth"];
        $expYear = $_POST["expYear"];
        $card_cvv = $_POST["card_cvv"];
        //$expMonth = $_POST['expMonth'];
        //$void = $_POST['void']

        //$result = $saleResponse($data);
        $result = $gateway->authorize(
            $amount,
            $currency,
            $cardNumber,
            $expMonth,
            $expYear,
            $card_cvv
        );
        //print_r($result);
        exit();
    }

    if ($session == "session") {
        $amount = $_POST["amount"];
        $currency = $_POST["currency"];
        $cardNumber = $_POST["cardNumber"];
        $expMonth = $_POST["expMonth"];
        $expYear = $_POST["expYear"];
        $card_cvv = $_POST["card_cvv"];
        //$expMonth = $_POST['expMonth'];
        //$void = $_POST['void']

        //$result = $saleResponse($data);
        $result = $gateway->Session(
            $amount,
            $currency,
            $cardNumber,
            $expMonth,
            $expYear,
            $card_cvv
        );
       // print_r($result);
        exit();
    }
    if ($sale == "sale") {
        $amount = $_POST["amount"];
        $currency = $_POST["currency"];
        $cardNumber = $_POST["cardNumber"];
        $expMonth = $_POST["expMonth"];
        $expYear = $_POST["expYear"];
        $card_cvv = $_POST["card_cvv"];
        //$expMonth = $_POST['expMonth'];
        //$void = $_POST['void']

        //$result = $saleResponse($data);
        $result = $gateway->sale(
            $amount,
            $currency,
            $cardNumber,
            $expMonth,
            $expYear,
            $card_cvv
        );
        //print_r($result);
        exit();
    }

    if ($capture == "capture") {
        $transactionId = $_POST["txt_id"];
        $captureResponse = $gateway->capture($transactionId);
        //print_r($captureResponse);
        exit();
    }

    if ($void == "void") {
        $transactionId = $_POST["txt_id"];
        $amount = $_POST["amount"];
        $void_txt_Response = $gateway->voidtxt($transactionId,$amount);
        //print_r($void_txt_Response);
        exit();
    }

    if ($refund == "refund") {
        $transactionId = $_POST["txt_id"];
        $amount = $_POST["amount"];
        $refundResponse = $gateway->refund($transactionId, $amount);
        //print_r($refundResponse);
        exit();
    }

    // Send response
}

?>
