<?php include 'header.php';?>

<head>
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#submitBtn').click(function(e){
                e.preventDefault();
                var formData = $('#auth').serialize(); // Serialize form data
                $.ajax({
                    type: 'POST',
                    url: 'withreachpaymentprocess.php',
                    data: formData,
                    success: function(response){
                        $('#result').html(response); // Display response
                    }
                });
            });
        });
    </script>
</head>
	 
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-3 px-7">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Auth</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Auth</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Auth</h6>
       
    <!-- End Navbar -->
    <div class="container-fluid py-1">
	
	  <div id="result"></div> <!-- Display response here -->
	  
       <div class="card-body">
                <form role="form text-left"  id="auth" action="withreachpaymentprocess.php" method="post">
                  <div class="mb-3">
                    <input type="text" class="form-control" placeholder="amount"  name ="amount" id="amount" aria-label="amount" aria-describedby="email-addon">
                  </div>
				  <div class="mb-3">
                    <input type="Number" class="form-control" placeholder="currency" name ="currency" id="currency"  aria-label="currency " aria-describedby="email-addon">
                  </div>
                  <div class="mb-3">
                    <input type="Number" class="form-control" placeholder="cardNumber" name ="cardNumber" id="cardNumber" aria-label="cardNumber" aria-describedby="email-addon">
                  </div>
				  <div class="mb-3">
                    <input type="Number" class="form-control" placeholder="expMonth" name ="expMonth" id="expMonth" aria-label="expMonth" aria-describedby="email-addon">
                  </div>
				  <div class="mb-3">
                    <input type="Number" class="form-control" placeholder="expYear" name ="expYear" id="expYear" aria-label="expYear" aria-describedby="email-addon">
                  </div>
				  <div class="mb-3">
                    <input type="text" class="form-control" placeholder="card_cvv" name ="card_cvv" id="card_cvv" aria-label="card_cvv" aria-describedby="email-addon">
                  </div>
				   <div class="mb-3">
                    <input type="hidden" class="form-control" placeholder="auth_txt"  name="auth_txt" id="auth_txt" aria-label="Auth" value ="auth" aria-describedby="email-addon">
                  </div>
                  
                  
                  <div class="text-center">
                    <button type="button" id="submitBtn" class="btn bg-gradient-dark w-100 my-4 mb-2">Place order</button>
                  </div>
                 
                </form>
              </div>
    </div>
	 
	  </nav>
      </div>
<?php include 'footer.php';?>
	 